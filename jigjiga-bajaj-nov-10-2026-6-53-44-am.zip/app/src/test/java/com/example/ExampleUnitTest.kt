package com.example

import com.example.data.model.ActiveRide
import com.example.data.model.AppLanguage
import com.example.data.model.JigjigaLocations
import com.example.data.model.LocalizedStrings
import com.example.data.model.MockDrivers
import com.example.data.model.PaymentType
import com.example.data.model.RideCategory
import com.example.data.model.RideOption
import com.example.data.model.RideStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun standardBajajFare_calculatesAccurately() {
    val standard = RideOption.defaultOptions.first { it.category == RideCategory.STANDARD }
    val distance = 4.0f
    val fare = standard.calculateFare(distance)
    // Base 30 ETB + (4 km * 15 ETB/km) = 90 ETB
    assertEquals(90, fare)
  }

  @Test
  fun expressPrivateBajajFare_calculatesAccurately() {
    val express = RideOption.defaultOptions.first { it.category == RideCategory.EXPRESS_PRIVATE }
    val distance = 3.0f
    val fare = express.calculateFare(distance)
    // Base 70 ETB + (3 km * 25 ETB/km) = 145 ETB
    assertEquals(145, fare)
  }

  @Test
  fun eBirrPaymentType_isAvailable() {
    val eBirr = PaymentType.entries.find { it == PaymentType.E_BIRR }
    assertNotNull(eBirr)
    assertEquals("E-Birr", eBirr?.displayName)
  }

  @Test
  fun activeRideTelemetry_storesPassengerAndDriverCoordinates() {
    val driver = MockDrivers.initialDrivers.first()
    val pickup = JigjigaLocations.WilwalSquare
    val dropoff = JigjigaLocations.TaiwanMarket
    val ride = ActiveRide(
      rideId = "BJ-1001",
      pickup = pickup,
      destination = dropoff,
      option = RideOption.defaultOptions.first(),
      driver = driver,
      fareEtb = 45,
      paymentType = PaymentType.E_BIRR,
      status = RideStatus.DRIVER_ASSIGNED,
      otpCode = "4819",
      currentProgress = 0.4f,
      currentBajajX = 49f,
      currentBajajY = 48f,
      driverBearing = 45f,
      passengerX = pickup.mapX,
      passengerY = pickup.mapY,
      distanceToPassengerMeters = 380,
      driverSpeedKmh = 32,
      remainingMinutes = 2
    )
    assertEquals(pickup.mapX, ride.passengerX)
    assertEquals(pickup.mapY, ride.passengerY)
    assertEquals(380, ride.distanceToPassengerMeters)
    assertEquals(32, ride.driverSpeedKmh)
  }

  @Test
  fun jigjigaLocations_hasWilwalSquareAndTaiwanMarket() {
    val places = JigjigaLocations.allPlaces
    assertTrue(places.size >= 8)
    val wilwal = places.find { it.id == "wilwal_square" }
    assertNotNull(wilwal)
    assertEquals("Taallada Wiilwaal", wilwal?.nameSo)

    val market = places.find { it.id == "taiwan_market" }
    assertNotNull(market)
    assertEquals("Suuqa Taywaan", market?.nameSo)
  }

  @Test
  fun multilingualSupport_returnsAppropriateLabels() {
    val somaliStrings = LocalizedStrings.get(AppLanguage.SOMALI)
    assertEquals("Jigjiga Bajaj", somaliStrings.appTitle)
    assertEquals("Rakaab", somaliStrings.commuterMode)
    assertEquals("Wade Bajaj", somaliStrings.driverMode)
    assertEquals("E-Birr", somaliStrings.eBirr)

    val amharicStrings = LocalizedStrings.get(AppLanguage.AMHARIC)
    assertEquals("ተሳፋሪ", amharicStrings.commuterMode)
    assertEquals("ኢ-ብር (E-Birr)", amharicStrings.eBirr)

    val englishStrings = LocalizedStrings.get(AppLanguage.ENGLISH)
    assertEquals("Commuter", englishStrings.commuterMode)
    assertEquals("E-Birr", englishStrings.eBirr)
  }
}
