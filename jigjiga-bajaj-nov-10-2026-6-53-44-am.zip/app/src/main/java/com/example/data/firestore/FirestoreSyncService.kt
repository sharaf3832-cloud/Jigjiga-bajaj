package com.example.data.firestore

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.ActiveRide
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.IgnoreExtraProperties
import kotlinx.coroutines.tasks.await

@IgnoreExtraProperties
data class CloudUserProfile(
  val userId: String = "",
  val displayName: String = "",
  val email: String = "",
  val role: String = "COMMUTER"
)

@IgnoreExtraProperties
data class CloudRideRecord(
  val userId: String = "",
  val rideId: String = "",
  val pickupName: String = "",
  val destinationName: String = "",
  val fareEtb: Double = 0.0,
  val driverName: String = "",
  val plateNumber: String = "",
  val paymentType: String = ""
)

class FirestoreSyncService(private val context: Context) {
  private val db: FirebaseFirestore by lazy {
    FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
  }

  suspend fun syncUserProfile(user: FirebaseUser, role: String = "COMMUTER") {
    try {
      val userDoc = db.collection("users").document(user.uid)
      val data = mapOf(
        "userId" to user.uid,
        "displayName" to (user.displayName ?: "Jigjiga Commuter"),
        "email" to (user.email ?: ""),
        "role" to role,
        "updatedAt" to FieldValue.serverTimestamp()
      )
      userDoc.set(data).await()
      Log.d("Firestore", "User profile synced for ${user.uid}")
    } catch (e: Exception) {
      Log.e("Firestore", "Failed to sync user profile: ${e.message}", e)
    }
  }

  suspend fun recordRideToCloud(ride: ActiveRide) {
    val uid = Firebase.auth.currentUser?.uid ?: return
    try {
      val rideDoc = db.collection("users").document(uid).collection("rides").document(ride.rideId)
      val data = mapOf(
        "userId" to uid,
        "rideId" to ride.rideId,
        "pickupName" to ride.pickup.nameEn,
        "destinationName" to ride.destination.nameEn,
        "fareEtb" to ride.fareEtb.toDouble(),
        "driverName" to ride.driver.name,
        "plateNumber" to ride.driver.plateNumber,
        "paymentType" to ride.paymentType.displayName,
        "createdAt" to FieldValue.serverTimestamp()
      )
      rideDoc.set(data).await()
      Log.d("Firestore", "Ride recorded to cloud: ${ride.rideId}")
    } catch (e: Exception) {
      Log.e("Firestore", "Failed to record ride to cloud: ${e.message}", e)
    }
  }
}
