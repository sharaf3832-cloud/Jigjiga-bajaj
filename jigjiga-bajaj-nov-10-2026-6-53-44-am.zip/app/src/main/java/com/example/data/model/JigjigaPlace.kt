package com.example.data.model

enum class PlaceCategory {
  LANDMARK,
  MARKET,
  UNIVERSITY,
  AIRPORT,
  HOSPITAL,
  RESIDENTIAL,
  STATION
}

data class JigjigaPlace(
  val id: String,
  val nameEn: String,
  val nameSo: String,
  val nameAm: String,
  val category: PlaceCategory,
  // Coordinates normalized [0f..100f] on Jigjiga Urban Map
  val mapX: Float,
  val mapY: Float,
  val shortDesc: String,
  val baseDistanceKm: Float
) {
  fun localizedName(lang: AppLanguage): String = when (lang) {
    AppLanguage.SOMALI -> nameSo
    AppLanguage.AMHARIC -> nameAm
    AppLanguage.ENGLISH -> nameEn
  }
}

object JigjigaLocations {
  val WilwalSquare = JigjigaPlace(
    id = "wilwal_square",
    nameEn = "Wilwal Square (Taallada)",
    nameSo = "Taallada Wiilwaal",
    nameAm = "ዊልዋል አደባባይ (ሃውልት)",
    category = PlaceCategory.LANDMARK,
    mapX = 50f,
    mapY = 50f,
    shortDesc = "City Center roundabout & iconic monument",
    baseDistanceKm = 0.8f
  )

  val TaiwanMarket = JigjigaPlace(
    id = "taiwan_market",
    nameEn = "Taiwan Market",
    nameSo = "Suuqa Taywaan",
    nameAm = "ታይዋን ገበያ",
    category = PlaceCategory.MARKET,
    mapX = 42f,
    mapY = 44f,
    shortDesc = "Busiest clothing, spice & electronics market",
    baseDistanceKm = 1.4f
  )

  val JigjigaUniversity = JigjigaPlace(
    id = "jigjiga_univ",
    nameEn = "Jigjiga University Main Campus",
    nameSo = "Jaamacadda Jigjiga (Kaambaska Weyn)",
    nameAm = "ጅግጅጋ ዩኒቨርሲቲ ዋና ግቢ",
    category = PlaceCategory.UNIVERSITY,
    mapX = 78f,
    mapY = 28f,
    shortDesc = "Higher education campus & student hostels",
    baseDistanceKm = 4.6f
  )

  val WilwalAirport = JigjigaPlace(
    id = "wilwal_airport",
    nameEn = "Garad Wilwal Airport",
    nameSo = "Gegada Diyaaradaha Wiilwaal",
    nameAm = "ገራድ ዊልዋል ኤርፖርት",
    category = PlaceCategory.AIRPORT,
    mapX = 22f,
    mapY = 82f,
    shortDesc = "Domestic passenger terminal & Ethiopian Airlines",
    baseDistanceKm = 7.8f
  )

  val KaramaraHospital = JigjigaPlace(
    id = "karamara_hospital",
    nameEn = "Karamara Referral Hospital",
    nameSo = "Isbitaalka Guud ee Karamara",
    nameAm = "ካራማራ ሪፈራል ሆስፒታል",
    category = PlaceCategory.HOSPITAL,
    mapX = 62f,
    mapY = 64f,
    shortDesc = "Emergency medical center & regional specialized care",
    baseDistanceKm = 2.5f
  )

  val QaryaanDhoodhi = JigjigaPlace(
    id = "qaryaan_dhoodhi",
    nameEn = "Qaryaan Dhoodhi",
    nameSo = "Xaafadda Qaryaan Dhoodhi",
    nameAm = "ቃርያን ዶዲ",
    category = PlaceCategory.RESIDENTIAL,
    mapX = 35f,
    mapY = 62f,
    shortDesc = "Vibrant residential neighborhood & cafes",
    baseDistanceKm = 3.1f
  )

  val SheedDheer = JigjigaPlace(
    id = "sheed_dheer",
    nameEn = "Sheed Dheer Junction",
    nameSo = "Isgoyska Sheed Dheer",
    nameAm = "ሼድ ዴር መገናኛ",
    category = PlaceCategory.STATION,
    mapX = 68f,
    mapY = 46f,
    shortDesc = "Active transit junction & local tea shops",
    baseDistanceKm = 2.9f
  )

  val Kebele06 = JigjigaPlace(
    id = "kebele_06",
    nameEn = "Kebele 06 / Dudahido",
    nameSo = "Dudahido (Qabalah 06)",
    nameAm = "ቀበሌ 06 ዱዳሂዶ",
    category = PlaceCategory.RESIDENTIAL,
    mapX = 58f,
    mapY = 32f,
    shortDesc = "Urban community & shopping streets",
    baseDistanceKm = 2.1f
  )

  val RegionalPalace = JigjigaPlace(
    id = "regional_palace",
    nameEn = "SRS Presidential Palace",
    nameSo = "Madaxtooyada Dawladda Deegaanka",
    nameAm = "የክልሉ ፕሬዝዳንት ቤተመንግስት",
    category = PlaceCategory.LANDMARK,
    mapX = 46f,
    mapY = 24f,
    shortDesc = "Government administrative headquarters",
    baseDistanceKm = 3.8f
  )

  val KaabaCheckpoint = JigjigaPlace(
    id = "kaaba_gate",
    nameEn = "Kaaba Gate (Customs)",
    nameSo = "Kantaroolka Kaaba",
    nameAm = "ካዕባ መፈተሻ",
    category = PlaceCategory.STATION,
    mapX = 86f,
    mapY = 68f,
    shortDesc = "Eastern highway entry and transport checkpoint",
    baseDistanceKm = 5.9f
  )

  val allPlaces = listOf(
    WilwalSquare,
    TaiwanMarket,
    JigjigaUniversity,
    WilwalAirport,
    KaramaraHospital,
    QaryaanDhoodhi,
    SheedDheer,
    Kebele06,
    RegionalPalace,
    KaabaCheckpoint
  )
}
