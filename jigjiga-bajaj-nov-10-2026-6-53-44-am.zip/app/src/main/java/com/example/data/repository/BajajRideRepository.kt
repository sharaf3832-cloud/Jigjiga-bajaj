package com.example.data.repository

import com.example.data.local.dao.RideHistoryDao
import com.example.data.local.dao.SavedPlaceDao
import com.example.data.local.entity.RideHistoryEntity
import com.example.data.local.entity.SavedPlaceEntity
import kotlinx.coroutines.flow.Flow

class BajajRideRepository(
  private val rideHistoryDao: RideHistoryDao,
  private val savedPlaceDao: SavedPlaceDao
) {
  val allRides: Flow<List<RideHistoryEntity>> = rideHistoryDao.getAllRides()
  val savedPlaces: Flow<List<SavedPlaceEntity>> = savedPlaceDao.getSavedPlaces()

  suspend fun insertCompletedRide(
    pickup: String,
    destination: String,
    fareEtb: Int,
    driverName: String,
    plateNumber: String,
    category: String,
    paymentType: String,
    rating: Int
  ) {
    val entity = RideHistoryEntity(
      pickupName = pickup,
      destinationName = destination,
      fareEtb = fareEtb,
      driverName = driverName,
      plateNumber = plateNumber,
      rideCategory = category,
      paymentType = paymentType,
      rating = rating
    )
    rideHistoryDao.insertRide(entity)
  }

  suspend fun saveCustomPlace(place: SavedPlaceEntity) {
    savedPlaceDao.insertOrUpdate(place)
  }

  suspend fun deleteSavedPlace(placeId: String) {
    savedPlaceDao.deletePlace(placeId)
  }

  suspend fun populateDefaultsIfNeeded(currentCount: Int) {
    if (currentCount == 0) {
      savedPlaceDao.insertOrUpdate(
        SavedPlaceEntity(
          placeId = "home_default",
          customLabel = "Home (Guriga)",
          locationName = "Dudahido (Qabalah 06)",
          mapX = 58f,
          mapY = 32f,
          iconTag = "HOME"
        )
      )
      savedPlaceDao.insertOrUpdate(
        SavedPlaceEntity(
          placeId = "work_default",
          customLabel = "Market (Suuqa)",
          locationName = "Suuqa Taywaan",
          mapX = 42f,
          mapY = 44f,
          iconTag = "WORK"
        )
      )
      savedPlaceDao.insertOrUpdate(
        SavedPlaceEntity(
          placeId = "study_default",
          customLabel = "Campus (Jaamacadda)",
          locationName = "Jaamacadda Jigjiga",
          mapX = 78f,
          mapY = 28f,
          iconTag = "SCHOOL"
        )
      )
    }
  }
}
