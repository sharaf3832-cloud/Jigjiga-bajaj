package com.example.data.model

enum class RideCategory {
  STANDARD,
  EXPRESS_PRIVATE,
  CARGO_DELIVERY
}

data class RideOption(
  val category: RideCategory,
  val baseFareEtb: Int,
  val perKmEtb: Int,
  val etaMinutes: Int,
  val capacityDesc: String,
  val iconEmoji: String
) {
  fun calculateFare(distanceKm: Float): Int {
    val distanceCharge = (distanceKm * perKmEtb).toInt()
    return baseFareEtb + distanceCharge
  }

  companion object {
    val defaultOptions = listOf(
      RideOption(
        category = RideCategory.STANDARD,
        baseFareEtb = 30,
        perKmEtb = 15,
        etaMinutes = 3,
        capacityDesc = "1-3 Seats",
        iconEmoji = "🛺"
      ),
      RideOption(
        category = RideCategory.EXPRESS_PRIVATE,
        baseFareEtb = 70,
        perKmEtb = 25,
        etaMinutes = 2,
        capacityDesc = "Private full cab",
        iconEmoji = "⚡"
      ),
      RideOption(
        category = RideCategory.CARGO_DELIVERY,
        baseFareEtb = 50,
        perKmEtb = 20,
        etaMinutes = 4,
        capacityDesc = "Luggage / Parcels",
        iconEmoji = "📦"
      )
    )
  }
}

enum class PaymentType(val displayName: String, val logoColorHex: Long) {
  CASH("Cash (Caddaan)", 0xFF10B981),
  E_BIRR("E-Birr", 0xFF0284C7),
  TELEBIRR("Telebirr", 0xFF0369A1),
  CBE_BIRR("CBE Birr", 0xFF854D0E),
  SAHAY_PAY("Sahay Pay", 0xFFE11D48)
}

data class BajajDriver(
  val id: String,
  val name: String,
  val phone: String,
  val plateNumber: String,
  val rating: Float,
  val totalRides: Int,
  val bajajColor: String,
  var currentX: Float,
  var currentY: Float,
  val isAvailable: Boolean = true
)

object MockDrivers {
  val initialDrivers = listOf(
    BajajDriver(
      id = "dr_1",
      name = "Mukhtar Farah",
      phone = "+251 91 520 4891",
      plateNumber = "ET-3-B-4819",
      rating = 4.9f,
      totalRides = 1420,
      bajajColor = "Royal Blue & White",
      currentX = 48f,
      currentY = 46f
    ),
    BajajDriver(
      id = "dr_2",
      name = "Guled Abdirahman",
      phone = "+251 92 314 8832",
      plateNumber = "ET-3-B-6102",
      rating = 4.8f,
      totalRides = 980,
      bajajColor = "Electric Blue",
      currentX = 40f,
      currentY = 48f
    ),
    BajajDriver(
      id = "dr_3",
      name = "Ahmed Nur",
      phone = "+251 91 588 1276",
      plateNumber = "ET-3-B-3354",
      rating = 4.95f,
      totalRides = 2100,
      bajajColor = "Blue with White Stripe",
      currentX = 54f,
      currentY = 53f
    ),
    BajajDriver(
      id = "dr_4",
      name = "Hassan Bihi",
      phone = "+251 94 402 9183",
      plateNumber = "ET-3-B-7741",
      rating = 4.75f,
      totalRides = 640,
      bajajColor = "Sky Blue & White",
      currentX = 45f,
      currentY = 42f
    ),
    BajajDriver(
      id = "dr_5",
      name = "Mustafe Ismail",
      phone = "+251 91 511 7420",
      plateNumber = "ET-3-B-8930",
      rating = 4.88f,
      totalRides = 1350,
      bajajColor = "Classic Blue Special",
      currentX = 64f,
      currentY = 45f
    )
  )
}
