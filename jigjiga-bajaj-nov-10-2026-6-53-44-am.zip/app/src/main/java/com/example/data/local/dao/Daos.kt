package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.RideHistoryEntity
import com.example.data.local.entity.SavedPlaceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RideHistoryDao {
  @Query("SELECT * FROM ride_history ORDER BY timestamp DESC")
  fun getAllRides(): Flow<List<RideHistoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRide(ride: RideHistoryEntity): Long

  @Query("DELETE FROM ride_history")
  suspend fun clearHistory()
}

@Dao
interface SavedPlaceDao {
  @Query("SELECT * FROM saved_places")
  fun getSavedPlaces(): Flow<List<SavedPlaceEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(place: SavedPlaceEntity)

  @Query("DELETE FROM saved_places WHERE placeId = :placeId")
  suspend fun deletePlace(placeId: String)
}
