package com.example.data.model

enum class RideStatus {
  IDLE,
  CHOOSING_DESTINATION,
  SEARCHING_DRIVER,
  DRIVER_ASSIGNED,
  DRIVER_ARRIVED,
  ON_TRIP,
  COMPLETED
}

data class ActiveRide(
  val rideId: String,
  val pickup: JigjigaPlace,
  val destination: JigjigaPlace,
  val option: RideOption,
  val driver: BajajDriver,
  val fareEtb: Int,
  val paymentType: PaymentType,
  val status: RideStatus,
  val otpCode: String,
  val currentProgress: Float, // 0.0f to 1.0f along active phase
  val currentBajajX: Float,
  val currentBajajY: Float,
  val driverBearing: Float = 0f, // 0..360 degrees
  val passengerX: Float = pickup.mapX,
  val passengerY: Float = pickup.mapY,
  val distanceToPassengerMeters: Int = 920,
  val driverSpeedKmh: Int = 28,
  val remainingMinutes: Int = 3
)
