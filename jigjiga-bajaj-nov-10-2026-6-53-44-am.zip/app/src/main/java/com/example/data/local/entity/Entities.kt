package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ride_history")
data class RideHistoryEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val timestamp: Long = System.currentTimeMillis(),
  val pickupName: String,
  val destinationName: String,
  val fareEtb: Int,
  val driverName: String,
  val plateNumber: String,
  val rideCategory: String,
  val paymentType: String,
  val rating: Int = 5
)

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
  @PrimaryKey
  val placeId: String,
  val customLabel: String,
  val locationName: String,
  val mapX: Float,
  val mapY: Float,
  val iconTag: String
)
