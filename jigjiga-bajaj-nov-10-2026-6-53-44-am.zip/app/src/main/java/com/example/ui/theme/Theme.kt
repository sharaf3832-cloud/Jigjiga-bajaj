package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = BajajBlueLight,
  onPrimary = Color(0xFF0F172A),
  primaryContainer = BajajBlueContainerDark,
  onPrimaryContainer = PureWhite,
  secondary = PureWhite,
  onSecondary = Color(0xFF0F172A),
  secondaryContainer = Color(0xFF1E293B),
  onSecondaryContainer = PureWhite,
  tertiary = EmeraldSuccess,
  onTertiary = Color.White,
  background = RoadNavyDark,
  onBackground = PureWhite,
  surface = RoadNavyCard,
  onSurface = PureWhite,
  surfaceVariant = RoadNavySurface,
  onSurfaceVariant = TextSecondaryDark,
  error = CoralAlert,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = BajajBluePrimary,
  onPrimary = PureWhite,
  primaryContainer = BajajBlueContainerLight,
  onPrimaryContainer = BajajBlueDark,
  secondary = BajajBlueDeep,
  onSecondary = PureWhite,
  secondaryContainer = Color(0xFFF1F5F9),
  onSecondaryContainer = Color(0xFF0F172A),
  tertiary = EmeraldSuccess,
  onTertiary = Color.White,
  background = SurfaceLight,
  onBackground = TextPrimaryLight,
  surface = SurfaceCardLight,
  onSurface = TextPrimaryLight,
  surfaceVariant = SurfaceTintLight,
  onSurfaceVariant = TextSecondaryLight,
  error = CoralAlert,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Preserve branded Blue & White Bajaj aesthetic
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
