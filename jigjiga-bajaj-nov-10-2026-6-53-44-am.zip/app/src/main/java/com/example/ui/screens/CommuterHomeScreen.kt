package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.JigjigaLocations
import com.example.data.model.JigjigaPlace
import com.example.data.model.LocalizedStrings
import com.example.data.model.PaymentType
import com.example.data.model.RideOption
import com.example.ui.components.DriverTrackingCard
import com.example.ui.components.JigjigaInteractiveMap
import com.example.ui.components.LanguageSelectorModal
import com.example.ui.components.RatingReceiptDialog
import com.example.ui.components.RideOptionCard
import com.example.ui.components.SafetySosDialog
import com.example.ui.viewmodel.BajajUiState
import com.example.ui.viewmodel.BajajViewModel
import com.example.ui.viewmodel.UserRole

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CommuterHomeScreen(
  viewModel: BajajViewModel,
  uiState: BajajUiState,
  modifier: Modifier = Modifier,
  onOpenAccount: () -> Unit = {}
) {
  val context = LocalContext.current
  val strings = LocalizedStrings.get(uiState.language)
  val scrollState = rememberScrollState()

  var pickupMenuExpanded by remember { mutableStateOf(false) }
  var dropoffMenuExpanded by remember { mutableStateOf(false) }

  Box(modifier = modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
    ) {
      // 1. App Header with Hero Visual Banner
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(130.dp)
          ) {
            Image(
              painter = painterResource(id = R.drawable.jigjiga_city_hero),
              contentDescription = "Jigjiga Bajaj Street",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
            // Gradient Overlay
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(Color(0x770F172A))
            )
            // Header Content
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "🛺 ${strings.appTitle}",
                    style = MaterialTheme.typography.titleLarge.copy(
                      fontWeight = FontWeight.ExtraBold,
                      color = Color.White
                    )
                  )
                }
                Text(
                  text = strings.tagline,
                  style = MaterialTheme.typography.labelSmall.copy(color = Color.White)
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                // Language selector pill
                Surface(
                  shape = RoundedCornerShape(16.dp),
                  color = Color(0xDD0F172A),
                  modifier = Modifier
                    .clickable { viewModel.toggleLanguageModal(true) }
                    .testTag("open_language_button")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      Icons.Default.Language,
                      contentDescription = "Language",
                      tint = Color(0xFF38BDF8),
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = uiState.language.label.take(5),
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // SOS Button
                IconButton(
                  onClick = { viewModel.toggleSosDialog(true) },
                  modifier = Modifier
                    .background(Color(0xEEEF4444), CircleShape)
                    .size(34.dp)
                    .testTag("header_sos_button")
                ) {
                  Icon(
                    Icons.Default.Security,
                    contentDescription = "SOS",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                  )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Account / Sign-In Button
                IconButton(
                  onClick = onOpenAccount,
                  modifier = Modifier
                    .background(Color(0xEE0284C7), CircleShape)
                    .size(34.dp)
                    .testTag("header_account_button")
                ) {
                  Icon(
                    Icons.Default.AccountCircle,
                    contentDescription = "Account",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
          }
        }
      }

      // 2. Real-Time Interactive Map Section
      val mapHeight = if (uiState.isMapExpanded) 460.dp else if (uiState.activeRide != null) 320.dp else 280.dp
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .height(mapHeight)
          .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
      ) {
        JigjigaInteractiveMap(
          modifier = Modifier.fillMaxSize(),
          places = JigjigaLocations.allPlaces,
          drivers = uiState.drivers,
          passengerX = uiState.passengerLiveX,
          passengerY = uiState.passengerLiveY,
          pickupPlace = uiState.pickup,
          dropoffPlace = uiState.dropoff,
          activeRide = uiState.activeRide,
          language = uiState.language,
          isExpanded = uiState.isMapExpanded,
          onToggleExpand = { viewModel.toggleMapExpanded() },
          onRecenterPassenger = { viewModel.recenterOnPassenger() },
          onPlaceSelected = { place ->
            if (uiState.dropoff == null) {
              viewModel.selectDropoff(place)
            } else {
              viewModel.selectPickup(place)
            }
          }
        )
      }

      // 3. Quick Landmark Destination Chips
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(
          text = "🌟 Popular Hubs in Jigjiga",
          style = MaterialTheme.typography.labelMedium.copy(
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
          )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          JigjigaLocations.allPlaces.take(6).forEach { place ->
            val isSelected = uiState.dropoff?.id == place.id
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.selectDropoff(place) },
              label = { Text(place.localizedName(uiState.language), fontSize = 12.sp) },
              leadingIcon = {
                Text(
                  text = when (place.category) {
                    com.example.data.model.PlaceCategory.MARKET -> "🛍️"
                    com.example.data.model.PlaceCategory.UNIVERSITY -> "🎓"
                    com.example.data.model.PlaceCategory.AIRPORT -> "✈️"
                    com.example.data.model.PlaceCategory.HOSPITAL -> "🏥"
                    com.example.data.model.PlaceCategory.LANDMARK -> "🏛️"
                    else -> "📍"
                  }
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
              ),
              modifier = Modifier.testTag("popular_chip_${place.id}")
            )
          }
        }
      }

      // 4. Booking Controls or Active Tracking Card
      if (uiState.activeRide != null) {
        DriverTrackingCard(
          activeRide = uiState.activeRide,
          language = uiState.language,
          onCallDriver = {
            Toast.makeText(context, "Dialing ${uiState.activeRide.driver.phone}...", Toast.LENGTH_SHORT).show()
          },
          onMessageDriver = {
            Toast.makeText(context, "SMS: 'I am waiting by the gate in Jigjiga'", Toast.LENGTH_SHORT).show()
          },
          onEmergencySos = { viewModel.toggleSosDialog(true) },
          onCancel = { viewModel.cancelRide() }
        )
      } else {
        // Booking Box
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            // Pickup & Destination Selector
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Pickup
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { pickupMenuExpanded = true }
                  .testTag("pickup_selector_row")
              ) {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFF10B981),
                  modifier = Modifier.size(24.dp)
                ) {
                  Icon(
                    Icons.Default.NearMe,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.padding(4.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = strings.pickupLocation,
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                  )
                  Text(
                    text = uiState.pickup.localizedName(uiState.language),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                  )
                }

                DropdownMenu(
                  expanded = pickupMenuExpanded,
                  onDismissRequest = { pickupMenuExpanded = false }
                ) {
                  JigjigaLocations.allPlaces.forEach { place ->
                    DropdownMenuItem(
                      text = { Text(place.localizedName(uiState.language)) },
                      onClick = {
                        viewModel.selectPickup(place)
                        pickupMenuExpanded = false
                      }
                    )
                  }
                }
              }

              // Dropoff Destination
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { dropoffMenuExpanded = true }
                  .testTag("dropoff_selector_row")
              ) {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFF0284C7),
                  modifier = Modifier.size(24.dp)
                ) {
                  Icon(
                    Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.padding(4.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = strings.destination,
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                  )
                  Text(
                    text = uiState.dropoff?.localizedName(uiState.language) ?: strings.whereTo,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = if (uiState.dropoff == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                  )
                }

                DropdownMenu(
                  expanded = dropoffMenuExpanded,
                  onDismissRequest = { dropoffMenuExpanded = false }
                ) {
                  JigjigaLocations.allPlaces.forEach { place ->
                    DropdownMenuItem(
                      text = { Text(place.localizedName(uiState.language)) },
                      onClick = {
                        viewModel.selectDropoff(place)
                        dropoffMenuExpanded = false
                      }
                    )
                  }
                }
              }
            }

            // Ride Options List
            val distance = viewModel.calculateTripDistance()
            Text(
              text = "🛺 Choose Bajaj Option (Est. ${String.format("%.1f", distance)} km)",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )

            RideOption.defaultOptions.forEach { opt ->
              RideOptionCard(
                option = opt,
                distanceKm = distance,
                isSelected = uiState.selectedRideOption.category == opt.category,
                language = uiState.language,
                onSelect = { viewModel.selectRideCategory(opt.category) }
              )
            }

            // Payment Method Selector
            Text(
              text = strings.paymentMethod,
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              PaymentType.entries.forEach { payment ->
                FilterChip(
                  selected = uiState.selectedPayment == payment,
                  onClick = { viewModel.selectPayment(payment) },
                  label = { Text(payment.displayName, fontSize = 12.sp) },
                  leadingIcon = {
                    Icon(
                      Icons.Default.Payment,
                      contentDescription = null,
                      modifier = Modifier.size(14.dp)
                    )
                  },
                  modifier = Modifier.testTag("payment_chip_${payment.name}")
                )
              }
            }

            // Primary Book Button
            val calculatedFare = viewModel.calculateFare()
            Button(
              onClick = { viewModel.startBookingRide() },
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
              ),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("book_bajaj_button")
            ) {
              Text(
                text = "${strings.bookNow} • $calculatedFare ${strings.birr}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(80.dp))
    }

    // Language Modal
    if (uiState.showLanguageModal) {
      LanguageSelectorModal(
        currentLanguage = uiState.language,
        onLanguageSelected = { viewModel.setLanguage(it) },
        onDismiss = { viewModel.toggleLanguageModal(false) }
      )
    }

    // Safety SOS Dialog
    if (uiState.showSosDialog) {
      SafetySosDialog(
        language = uiState.language,
        pickup = uiState.pickup.localizedName(uiState.language),
        destination = uiState.dropoff?.localizedName(uiState.language) ?: "Jigjiga City Center",
        plateNumber = uiState.activeRide?.driver?.plateNumber,
        onDismiss = { viewModel.toggleSosDialog(false) }
      )
    }

    // Rating Receipt Dialog
    if (uiState.showRatingDialog && uiState.activeRide != null) {
      RatingReceiptDialog(
        activeRide = uiState.activeRide,
        language = uiState.language,
        onSubmitRating = { rating -> viewModel.submitRating(rating) }
      )
    }
  }
}
