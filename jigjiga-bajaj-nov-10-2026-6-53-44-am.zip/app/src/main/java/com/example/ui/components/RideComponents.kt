package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveRide
import com.example.data.model.AppLanguage
import com.example.data.model.LocalizedStrings
import com.example.data.model.RideCategory
import com.example.data.model.RideOption
import com.example.data.model.RideStatus

@Composable
fun RideOptionCard(
  option: RideOption,
  distanceKm: Float,
  isSelected: Boolean,
  language: AppLanguage,
  onSelect: () -> Unit
) {
  val strings = LocalizedStrings.get(language)
  val title = when (option.category) {
    RideCategory.STANDARD -> strings.standardBajaj
    RideCategory.EXPRESS_PRIVATE -> strings.expressPrivate
    RideCategory.CARGO_DELIVERY -> strings.cargoBajaj
  }
  val desc = when (option.category) {
    RideCategory.STANDARD -> strings.standardDesc
    RideCategory.EXPRESS_PRIVATE -> strings.expressDesc
    RideCategory.CARGO_DELIVERY -> strings.cargoDesc
  }
  val fare = option.calculateFare(distanceKm)

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onSelect() }
      .testTag("ride_option_${option.category.name}"),
    shape = RoundedCornerShape(16.dp),
    border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
      else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Icon Box
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.size(48.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Text(text = option.iconEmoji, fontSize = 24.sp)
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${option.etaMinutes} min",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            )
          }
        }
        Text(
          text = desc,
          style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "$fare ${strings.birr}",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
          )
        )
        Text(
          text = option.capacityDesc,
          style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
      }
    }
  }
}

@Composable
fun DriverTrackingCard(
  activeRide: ActiveRide,
  language: AppLanguage,
  onCallDriver: () -> Unit,
  onMessageDriver: () -> Unit,
  onEmergencySos: () -> Unit,
  onCancel: () -> Unit
) {
  val strings = LocalizedStrings.get(language)
  val statusText = when (activeRide.status) {
    RideStatus.SEARCHING_DRIVER -> strings.searchingDriver
    RideStatus.DRIVER_ASSIGNED -> "Driver Approaching: ${activeRide.distanceToPassengerMeters}m away (${activeRide.remainingMinutes} min)"
    RideStatus.DRIVER_ARRIVED -> "🛺 ${strings.bajajArrived}"
    RideStatus.ON_TRIP -> "${strings.inTripTo} ${activeRide.destination.localizedName(language)} (${activeRide.remainingMinutes} min)"
    RideStatus.COMPLETED -> strings.rideCompleted
    else -> ""
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("driver_tracking_card"),
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Status header with progress bar
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (activeRide.status == RideStatus.SEARCHING_DRIVER) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.width(8.dp))
            } else {
              Surface(
                shape = CircleShape,
                color = when (activeRide.status) {
                  RideStatus.DRIVER_ARRIVED -> Color(0xFF10B981)
                  RideStatus.ON_TRIP -> MaterialTheme.colorScheme.primary
                  else -> Color(0xFF0284C7)
                },
                modifier = Modifier.size(10.dp)
              ) {}
              Spacer(modifier = Modifier.width(8.dp))
            }

            Text(
              text = statusText,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              maxLines = 2
            )
          }

          if (activeRide.status != RideStatus.ON_TRIP && activeRide.status != RideStatus.COMPLETED) {
            IconButton(
              onClick = onCancel,
              modifier = Modifier.testTag("cancel_ride_button")
            ) {
              Icon(Icons.Default.Close, contentDescription = "Cancel")
            }
          }
        }

        if (activeRide.status == RideStatus.DRIVER_ASSIGNED) {
          Spacer(modifier = Modifier.height(8.dp))
          val approachProgress = (1f - (activeRide.distanceToPassengerMeters.toFloat() / 1000f)).coerceIn(0.05f, 0.98f)
          LinearProgressIndicator(
            progress = { approachProgress },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = Color(0xFF0284C7),
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        } else if (activeRide.status == RideStatus.ON_TRIP) {
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { activeRide.currentProgress },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        }
      }

      // Driver details row
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Driver avatar
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(54.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(
              text = activeRide.driver.name.take(2).uppercase(),
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
            )
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = activeRide.driver.name,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = null,
              tint = Color(0xFFF59E0B),
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = " ${activeRide.driver.rating} • ${activeRide.driver.totalRides} trips",
              style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
          }
          // Plate badge
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = Color(0xFF0284C7),
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Text(
              text = " 🛺 ${activeRide.driver.plateNumber} ",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
            )
          }
        }

        // OTP PIN Badge
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "Pickup PIN",
            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
          )
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Text(
              text = activeRide.otpCode,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
        }
      }

      // Quick Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = onCallDriver,
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          modifier = Modifier
            .weight(1f)
            .testTag("call_driver_button")
        ) {
          Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(strings.callDriver, fontSize = 13.sp)
        }

        OutlinedButton(
          onClick = onMessageDriver,
          modifier = Modifier
            .weight(1f)
            .testTag("message_driver_button")
        ) {
          Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(strings.messageDriver, fontSize = 13.sp)
        }

        IconButton(
          onClick = onEmergencySos,
          modifier = Modifier
            .background(Color(0x22EF4444), CircleShape)
            .testTag("sos_button")
        ) {
          Icon(Icons.Default.Security, contentDescription = "SOS", tint = Color(0xFFEF4444))
        }
      }
    }
  }
}
