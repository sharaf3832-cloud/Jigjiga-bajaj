package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveRide
import com.example.data.model.AppLanguage
import com.example.data.model.LocalizedStrings

@Composable
fun RatingReceiptDialog(
  activeRide: ActiveRide,
  language: AppLanguage,
  onSubmitRating: (Int) -> Unit
) {
  val strings = LocalizedStrings.get(language)
  var rating by remember { mutableIntStateOf(5) }
  var selectedTip by remember { mutableIntStateOf(0) }

  AlertDialog(
    onDismissRequest = { onSubmitRating(rating) },
    modifier = Modifier.testTag("rating_receipt_dialog"),
    title = {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
      ) {
        Surface(
          shape = CircleShape,
          color = Color(0xFF10B981).copy(alpha = 0.2f),
          modifier = Modifier.size(56.dp)
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.padding(10.dp)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = strings.rideCompleted,
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        )
      }
    },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
      ) {
        // Receipt Card
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Total Fare:", fontWeight = FontWeight.Medium)
              Text(
                text = "${activeRide.fareEtb + selectedTip} ${strings.birr}",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 16.sp
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Payment:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
              Text(text = activeRide.paymentType.displayName, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Driver:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
              Text(text = "${activeRide.driver.name} (${activeRide.driver.plateNumber})", fontSize = 13.sp)
            }
          }
        }

        Text(
          text = strings.rateRide,
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
        )

        // 5 Star Selector
        Row(
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier.fillMaxWidth()
        ) {
          for (i in 1..5) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = "$i stars",
              tint = if (i <= rating) Color(0xFFF59E0B) else Color(0xFF64748B),
              modifier = Modifier
                .size(36.dp)
                .clickable { rating = i }
                .padding(2.dp)
                .testTag("rate_star_$i")
            )
          }
        }

        // Tip Driver Chips
        Text(
          text = "Tip Driver (Optional):",
          style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          listOf(0, 10, 20, 50).forEach { tip ->
            FilterChip(
              selected = selectedTip == tip,
              onClick = { selectedTip = tip },
              label = { Text(if (tip == 0) "No Tip" else "+$tip ${strings.birr}") }
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSubmitRating(rating) },
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("submit_rating_receipt_button")
      ) {
        Text(strings.done)
      }
    }
  )
}
