package com.example.ui.components

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.auth.AuthManager
import com.example.data.model.AppLanguage
import com.google.firebase.auth.FirebaseUser

@Composable
fun GoogleSignInButton(
  authManager: AuthManager,
  onAuthSuccess: (FirebaseUser) -> Unit,
  onAuthError: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val scope = rememberCoroutineScope()
  var isLoading by remember { mutableStateOf(false) }

  Button(
    onClick = {
      if (activity != null) {
        isLoading = true
        authManager.signInWithGoogle(
          activity = activity,
          scope = scope,
          onAuthSuccess = { user ->
            isLoading = false
            onAuthSuccess(user)
          },
          onAuthError = { err ->
            isLoading = false
            onAuthError(err)
          },
          onAuthCancelled = {
            isLoading = false
          }
        )
      }
    },
    enabled = !isLoading,
    shape = RoundedCornerShape(14.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = Color.White,
      contentColor = Color(0xFF1E293B)
    ),
    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .height(52.dp)
      .testTag("google_sign_in_button")
  ) {
    if (isLoading) {
      CircularProgressIndicator(
        modifier = Modifier.size(24.dp),
        strokeWidth = 2.dp,
        color = Color(0xFF0284C7)
      )
    } else {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Surface(
          shape = CircleShape,
          color = Color(0xFF4285F4),
          modifier = Modifier.size(26.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(text = "G", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
          text = "Sign in with Google",
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = Color(0xFF1E293B)
        )
      }
    }
  }
}

@Composable
fun AuthGateScreen(
  authManager: AuthManager,
  language: AppLanguage,
  onContinue: () -> Unit
) {
  var errorMessage by remember { mutableStateOf<String?>(null) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B192C))
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        shape = CircleShape,
        color = Color(0xFF0284C7),
        modifier = Modifier.size(96.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Text(text = "🛺", fontSize = 48.sp)
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = "Jigjiga Bajaj",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.ExtraBold,
          color = Color.White
        )
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = when (language) {
          AppLanguage.SOMALI -> "Ku xirnow gaadiidka bajajta ee magaalada Jigjiga"
          AppLanguage.AMHARIC -> "ከጅግጅጋ ፈጣን ባጃጅ ትራንስፖርት ጋር ይገናኙ"
          AppLanguage.ENGLISH -> "Connect with verified Bajaj drivers across Jigjiga"
        },
        style = MaterialTheme.typography.bodyMedium.copy(
          color = Color(0xFF94A3B8),
          textAlign = TextAlign.Center
        ),
        modifier = Modifier.padding(horizontal = 16.dp)
      )

      Spacer(modifier = Modifier.height(36.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Security,
              contentDescription = null,
              tint = Color(0xFF38BDF8),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Secure Google Authentication",
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 14.sp
            )
          }

          Text(
            text = "Sign in to save your ride receipts, favorite Jigjiga hubs, and access quick booking dispatch.",
            fontSize = 13.sp,
            color = Color(0xFF94A3B8)
          )

          errorMessage?.let { err ->
            Text(
              text = err,
              color = Color(0xFFEF4444),
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }

          GoogleSignInButton(
            authManager = authManager,
            onAuthSuccess = { onContinue() },
            onAuthError = { errorMessage = it }
          )

          OutlinedButton(
            onClick = onContinue,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("continue_as_guest_button")
          ) {
            Text(
              text = "Continue to App",
              color = Color(0xFF38BDF8),
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}

@Composable
fun UserAccountDialog(
  user: FirebaseUser?,
  authManager: AuthManager,
  onDismiss: () -> Unit
) {
  val scope = rememberCoroutineScope()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          shape = CircleShape,
          color = Color(0xFF0284C7),
          modifier = Modifier.size(36.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(
              text = user?.displayName?.take(1)?.uppercase() ?: "U",
              color = Color.White,
              fontWeight = FontWeight.Bold
            )
          }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "User Account",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
      }
    },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        if (user != null) {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = user.displayName ?: "Jigjiga Commuter",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text(
                text = user.email ?: "",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "UID: ${user.uid.take(12)}...",
                fontSize = 11.sp,
                color = Color(0xFF0284C7),
                fontWeight = FontWeight.Medium
              )
            }
          }

          Button(
            onClick = {
              authManager.signOut(scope) {
                onDismiss()
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("auth_sign_out_button")
          ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sign Out")
          }
        } else {
          Text(text = "You are currently browsing as a guest.")
          GoogleSignInButton(
            authManager = authManager,
            onAuthSuccess = { onDismiss() },
            onAuthError = {}
          )
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("Close")
      }
    }
  )
}
