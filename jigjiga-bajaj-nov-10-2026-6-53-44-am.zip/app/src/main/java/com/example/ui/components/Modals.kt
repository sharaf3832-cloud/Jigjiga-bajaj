package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.LocalizedStrings

@Composable
fun LanguageSelectorModal(
  currentLanguage: AppLanguage,
  onLanguageSelected: (AppLanguage) -> Unit,
  onDismiss: () -> Unit
) {
  val strings = LocalizedStrings.get(currentLanguage)

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("language_selector_dialog"),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Language,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = strings.language,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        AppLanguage.entries.forEach { lang ->
          val isSelected = lang == currentLanguage
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onLanguageSelected(lang) }
              .testTag("lang_option_${lang.code}"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
              else MaterialTheme.colorScheme.surfaceVariant
            )
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = lang.label,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                  else MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = when (lang) {
                    AppLanguage.SOMALI -> "Afka rasmiga ah ee Deegaanka Soomaalida"
                    AppLanguage.AMHARIC -> "የኢትዮጵያ ፌዴራላዊ ቋንቋ"
                    AppLanguage.ENGLISH -> "International English"
                  },
                  fontSize = 12.sp,
                  color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                  else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = "Selected",
                  tint = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("close_language_modal")
      ) {
        Text(strings.done)
      }
    }
  )
}

@Composable
fun SafetySosDialog(
  language: AppLanguage,
  pickup: String,
  destination: String,
  plateNumber: String?,
  onDismiss: () -> Unit
) {
  val strings = LocalizedStrings.get(language)

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("sos_emergency_dialog"),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          shape = CircleShape,
          color = Color(0xFFEF4444),
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "SOS",
            tint = Color.White,
            modifier = Modifier.padding(6.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = strings.emergencySos,
          style = MaterialTheme.typography.titleLarge.copy(
            color = Color(0xFFEF4444),
            fontWeight = FontWeight.Bold
          )
        )
      }
    },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(top = 8.dp)
      ) {
        Text(
          text = strings.safetyNotice,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
        )

        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "📍 Live Ride Coordinates",
              style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.primary)
            )
            Text(text = "From: $pickup", fontSize = 13.sp)
            Text(text = "To: $destination", fontSize = 13.sp)
            plateNumber?.let {
              Text(
                text = "Vehicle Plate: $it",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = { /* Simulated Police Call */ onDismiss() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            modifier = Modifier
              .weight(1f)
              .testTag("call_police_button")
          ) {
            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Police 991", fontSize = 12.sp)
          }

          OutlinedButton(
            onClick = { /* Simulated Share Link */ onDismiss() },
            modifier = Modifier
              .weight(1f)
              .testTag("share_trip_sos_button")
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Share Trip", fontSize = 12.sp)
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("Close")
      }
    }
  )
}
