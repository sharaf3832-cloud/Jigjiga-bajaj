package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveRide
import com.example.data.model.AppLanguage
import com.example.data.model.BajajDriver
import com.example.data.model.JigjigaPlace
import com.example.data.model.RideStatus
import kotlin.math.hypot

@Composable
fun JigjigaInteractiveMap(
  modifier: Modifier = Modifier,
  places: List<JigjigaPlace>,
  drivers: List<BajajDriver>,
  passengerX: Float,
  passengerY: Float,
  pickupPlace: JigjigaPlace?,
  dropoffPlace: JigjigaPlace?,
  activeRide: ActiveRide?,
  language: AppLanguage,
  isExpanded: Boolean = false,
  onToggleExpand: () -> Unit = {},
  onRecenterPassenger: () -> Unit = {},
  onPlaceSelected: (JigjigaPlace) -> Unit
) {
  val textMeasurer = rememberTextMeasurer()
  val infiniteTransition = rememberInfiniteTransition(label = "map_animations")

  // Radar pulse animations
  val pulseRadiusFraction by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(2200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "pulse_radar"
  )

  val beaconPulse by infiniteTransition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(1400, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "beacon_pulse"
  )

  // Route dash phase animation
  val dashPhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 60f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "dash_phase"
  )

  Box(modifier = modifier) {
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(places) {
          detectTapGestures { tapOffset ->
            val w = size.width
            val h = size.height
            var closestPlace: JigjigaPlace? = null
            var minDistance = Float.MAX_VALUE
            for (p in places) {
              val px = (p.mapX / 100f) * w
              val py = (p.mapY / 100f) * h
              val dist = hypot(tapOffset.x - px, tapOffset.y - py)
              if (dist < 120f && dist < minDistance) {
                minDistance = dist
                closestPlace = p
              }
            }
            closestPlace?.let { onPlaceSelected(it) }
          }
        }
    ) {
      val w = size.width
      val h = size.height

      // 1. Urban Canvas Base (Deep Blue Navy gradient)
      drawRect(
        brush = Brush.radialGradient(
          colors = listOf(Color(0xFF1E293B), Color(0xFF0B192C)),
          center = Offset(w * 0.5f, h * 0.5f),
          radius = w * 0.8f
        )
      )

      // 2. City Blocks & Districts
      drawUrbanDistricts(w, h)

      // 3. Jigjiga Major Road Network (Crisp Blue & White lines)
      drawRoadNetwork(w, h)

      // 4. Central Roundabout (Taallada Wiilwaal)
      val centerRoundabout = Offset(w * 0.5f, h * 0.5f)
      drawCircle(
        color = Color(0xFF0B192C),
        radius = 28f,
        center = centerRoundabout
      )
      drawCircle(
        color = Color(0xFF0284C7),
        radius = 28f,
        center = centerRoundabout,
        style = Stroke(width = 4f)
      )
      drawCircle(
        color = Color.White,
        radius = 12f,
        center = centerRoundabout
      )
      drawCircle(
        color = Color(0xFF0284C7),
        radius = 6f,
        center = centerRoundabout
      )

      // 5. Draw City Landmarks & Labels
      for (place in places) {
        val px = (place.mapX / 100f) * w
        val py = (place.mapY / 100f) * h
        val isPickup = place.id == pickupPlace?.id
        val isDropoff = place.id == dropoffPlace?.id

        if (!isPickup && !isDropoff) {
          drawCircle(
            color = Color(0x66334155),
            radius = 16f,
            center = Offset(px, py)
          )
          drawCircle(
            color = Color(0xFF94A3B8),
            radius = 6f,
            center = Offset(px, py)
          )

          val label = place.localizedName(language).take(14)
          val measured = textMeasurer.measure(
            text = label,
            style = TextStyle(
              fontSize = 9.sp,
              color = Color(0xFFE2E8F0),
              fontWeight = FontWeight.Medium
            )
          )
          drawText(
            textMeasurer = textMeasurer,
            text = label,
            topLeft = Offset(px - measured.size.width / 2f, py + 10f),
            style = TextStyle(
              fontSize = 9.sp,
              color = Color(0xFFE2E8F0),
              fontWeight = FontWeight.Medium
            )
          )
        }
      }

      // 6. REAL-TIME ROUTE & TRAJECTORY
      if (activeRide != null) {
        val passPos = Offset((activeRide.passengerX / 100f) * w, (activeRide.passengerY / 100f) * h)
        val driverPos = Offset((activeRide.currentBajajX / 100f) * w, (activeRide.currentBajajY / 100f) * h)

        if (activeRide.status == RideStatus.DRIVER_ASSIGNED) {
          // Approach Route: Connects Driver to Passenger in real time!
          val approachPath = Path().apply {
            moveTo(driverPos.x, driverPos.y)
            val midX = (driverPos.x + passPos.x) / 2f
            val midY = (driverPos.y + passPos.y) / 2f
            cubicTo(driverPos.x, midY, midX, passPos.y, passPos.x, passPos.y)
          }

          // Glowing blue trajectory line
          drawPath(
            path = approachPath,
            color = Color(0x440284C7),
            style = Stroke(width = 12f, cap = StrokeCap.Round, join = StrokeJoin.Round)
          )
          drawPath(
            path = approachPath,
            color = Color(0xFF38BDF8),
            style = Stroke(
              width = 5f,
              cap = StrokeCap.Round,
              join = StrokeJoin.Round,
              pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), dashPhase)
            )
          )
        } else if (activeRide.status == RideStatus.ON_TRIP || activeRide.status == RideStatus.DRIVER_ARRIVED) {
          // Trip Route: Connects Passenger/Pickup to Destination
          dropoffPlace?.let { d ->
            val pEnd = Offset((d.mapX / 100f) * w, (d.mapY / 100f) * h)
            val tripPath = Path().apply {
              moveTo(passPos.x, passPos.y)
              val midX = (passPos.x + pEnd.x) / 2f
              val midY = (passPos.y + pEnd.y) / 2f
              cubicTo(passPos.x, midY, midX, pEnd.y, pEnd.x, pEnd.y)
            }

            drawPath(
              path = tripPath,
              color = Color(0x330284C7),
              style = Stroke(width = 14f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
              path = tripPath,
              color = Color(0xFF0284C7),
              style = Stroke(
                width = 6f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), dashPhase)
              )
            )
          }
        }
      } else if (pickupPlace != null && dropoffPlace != null) {
        // Standard preview route between pickup & dropoff
        val pStart = Offset((pickupPlace.mapX / 100f) * w, (pickupPlace.mapY / 100f) * h)
        val pEnd = Offset((dropoffPlace.mapX / 100f) * w, (dropoffPlace.mapY / 100f) * h)

        val routePath = Path().apply {
          moveTo(pStart.x, pStart.y)
          val midX = (pStart.x + pEnd.x) / 2f
          val midY = (pStart.y + pEnd.y) / 2f
          cubicTo(pStart.x, midY, midX, pEnd.y, pEnd.x, pEnd.y)
        }

        drawPath(
          path = routePath,
          color = Color(0x440284C7),
          style = Stroke(width = 12f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(
          path = routePath,
          color = Color(0xFF38BDF8),
          style = Stroke(
            width = 6f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), dashPhase)
          )
        )
      }

      // 7. Draw Other Unassigned Nearby Drivers (cruising in Jigjiga)
      val activeDriverId = activeRide?.driver?.id
      for (driver in drivers) {
        if (driver.id != activeDriverId) {
          val dx = (driver.currentX / 100f) * w
          val dy = (driver.currentY / 100f) * h
          drawBajajMarker(
            center = Offset(dx, dy),
            isAssigned = false,
            bearing = 0f,
            plate = driver.plateNumber.takeLast(4)
          )
        }
      }

      // 8. REAL-TIME ASSIGNED BAJAJ DRIVER (with bearing, headlights, and telemetry)
      activeRide?.let { ride ->
        val bx = (ride.currentBajajX / 100f) * w
        val by = (ride.currentBajajY / 100f) * h
        val isArrived = ride.status == RideStatus.DRIVER_ARRIVED

        // Driver pulsating aura
        drawCircle(
          color = if (isArrived) Color(0x4410B981) else Color(0x550284C7),
          radius = 42f * (0.7f + pulseRadiusFraction * 0.3f),
          center = Offset(bx, by)
        )

        // Draw Bajaj Vehicle at exact coordinates and bearing
        drawBajajMarker(
          center = Offset(bx, by),
          isAssigned = true,
          bearing = ride.driverBearing,
          plate = ride.driver.plateNumber.takeLast(4)
        )

        // Driver floating identity banner
        val bannerText = "🛺 ${ride.driver.name} • ${ride.driverSpeedKmh} km/h"
        val measured = textMeasurer.measure(
          text = bannerText,
          style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        )
        drawRoundRect(
          color = Color(0xEE0B192C),
          topLeft = Offset(bx - measured.size.width / 2f - 10f, by - 44f),
          size = Size(measured.size.width + 20f, 22f),
          cornerRadius = CornerRadius(10f, 10f)
        )
        drawText(
          textMeasurer = textMeasurer,
          text = bannerText,
          topLeft = Offset(bx - measured.size.width / 2f, by - 41f),
          style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
        )
      }

      // 9. REAL-TIME PASSENGER LOCATION (Pulsing beacon + User pinpoint)
      val passX = (passengerX / 100f) * w
      val passY = (passengerY / 100f) * h

      // Passenger GPS accuracy halo & pulsating beacon
      drawCircle(
        color = Color(0x220284C7),
        radius = 50f * (0.8f + pulseRadiusFraction * 0.4f),
        center = Offset(passX, passY)
      )
      drawCircle(
        color = Color(0x4438BDF8),
        radius = 28f * beaconPulse,
        center = Offset(passX, passY)
      )

      // Outer ring
      drawCircle(
        color = Color.White,
        radius = 14f,
        center = Offset(passX, passY)
      )
      // Solid Blue center
      drawCircle(
        color = Color(0xFF0284C7),
        radius = 11f,
        center = Offset(passX, passY)
      )
      // Person dot
      drawCircle(
        color = Color.White,
        radius = 5f,
        center = Offset(passX, passY)
      )

      // Passenger Floating Tooltip Badge
      val passLabel = "👤 You (Passenger)"
      val measuredPass = textMeasurer.measure(
        text = passLabel,
        style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
      )
      drawRoundRect(
        color = Color(0xEE0284C7),
        topLeft = Offset(passX - measuredPass.size.width / 2f - 10f, passY + 16f),
        size = Size(measuredPass.size.width + 20f, 22f),
        cornerRadius = CornerRadius(10f, 10f)
      )
      drawText(
        textMeasurer = textMeasurer,
        text = passLabel,
        topLeft = Offset(passX - measuredPass.size.width / 2f, passY + 19f),
        style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
      )

      // 10. Destination Dropoff Pin (if specified)
      dropoffPlace?.let { d ->
        val dx = (d.mapX / 100f) * w
        val dy = (d.mapY / 100f) * h

        drawCircle(
          color = Color(0x550284C7),
          radius = 30f * (0.7f + pulseRadiusFraction * 0.3f),
          center = Offset(dx, dy)
        )
        drawCircle(
          color = Color(0xFF0284C7),
          radius = 12f,
          center = Offset(dx, dy)
        )
        drawCircle(
          color = Color.White,
          radius = 5f,
          center = Offset(dx, dy)
        )

        val dropLabel = "🏁 " + d.localizedName(language).take(16)
        val measured = textMeasurer.measure(
          text = dropLabel,
          style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        )
        drawRoundRect(
          color = Color(0xEE0369A1),
          topLeft = Offset(dx - measured.size.width / 2f - 10f, dy - 38f),
          size = Size(measured.size.width + 20f, 24f),
          cornerRadius = CornerRadius(12f, 12f)
        )
        drawText(
          textMeasurer = textMeasurer,
          text = dropLabel,
          topLeft = Offset(dx - measured.size.width / 2f, dy - 34f),
          style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        )
      }
    }

    // Top Header: Live Real-Time Telemetry Bar (when ride is active)
    if (activeRide != null) {
      Surface(
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(horizontal = 10.dp, vertical = 8.dp)
          .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xEE0B192C),
        tonalElevation = 6.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color(0xFF0284C7),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(text = "🛺", fontSize = 16.sp)
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = activeRide.driver.name,
                style = MaterialTheme.typography.labelLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
              Text(
                text = "Plate: ${activeRide.driver.plateNumber}",
                style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8))
              )
            }
          }

          Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Speed telemetry
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF1E293B)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Speed,
                  contentDescription = null,
                  tint = Color(0xFF38BDF8),
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = "${activeRide.driverSpeedKmh} km/h",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }

            // Distance / ETA
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF0284C7)
            ) {
              Text(
                text = if (activeRide.status == RideStatus.DRIVER_ASSIGNED)
                  "${activeRide.distanceToPassengerMeters}m (${activeRide.remainingMinutes}m)"
                else
                  "${activeRide.remainingMinutes} min ETA",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }
        }
      }
    } else {
      // Idle City Map Badge
      Surface(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(12.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xEE0B192C),
        tonalElevation = 4.dp
      ) {
        Text(
          text = "📍 Jigjiga Real-Time Radar",
          style = MaterialTheme.typography.labelMedium.copy(
            color = Color(0xFF38BDF8),
            fontWeight = FontWeight.SemiBold
          ),
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
      }
    }

    // Floating Map Action Buttons (Bottom Right)
    Column(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Re-center on Passenger GPS Button
      Surface(
        shape = CircleShape,
        color = Color(0xEE0B192C),
        tonalElevation = 4.dp,
        modifier = Modifier
          .size(40.dp)
          .clickable { onRecenterPassenger() }
          .testTag("recenter_passenger_button")
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            Icons.Default.MyLocation,
            contentDescription = "Center on Passenger",
            tint = Color(0xFF38BDF8),
            modifier = Modifier.size(20.dp)
          )
        }
      }

      // Expand / Fullscreen Map Toggle Button
      Surface(
        shape = CircleShape,
        color = Color(0xEE0B192C),
        tonalElevation = 4.dp,
        modifier = Modifier
          .size(40.dp)
          .clickable { onToggleExpand() }
          .testTag("expand_map_button")
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            if (isExpanded) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
            contentDescription = "Toggle Fullscreen Map",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

private fun DrawScope.drawUrbanDistricts(w: Float, h: Float) {
  val districtBrush = Brush.linearGradient(
    listOf(Color(0x150284C7), Color(0x0A0F172A))
  )

  // Taiwan Market commercial block
  drawRoundRect(
    brush = districtBrush,
    topLeft = Offset(w * 0.32f, h * 0.38f),
    size = Size(w * 0.22f, h * 0.16f),
    cornerRadius = CornerRadius(16f, 16f)
  )

  // University campus block
  drawRoundRect(
    color = Color(0x1538BDF8),
    topLeft = Offset(w * 0.70f, h * 0.20f),
    size = Size(w * 0.24f, h * 0.20f),
    cornerRadius = CornerRadius(20f, 20f)
  )

  // Airport southern zone
  drawRoundRect(
    brush = districtBrush,
    topLeft = Offset(w * 0.12f, h * 0.74f),
    size = Size(w * 0.28f, h * 0.18f),
    cornerRadius = CornerRadius(20f, 20f)
  )

  // Qaryaan Dhoodhi zone
  drawRoundRect(
    brush = districtBrush,
    topLeft = Offset(w * 0.24f, h * 0.56f),
    size = Size(w * 0.26f, h * 0.16f),
    cornerRadius = CornerRadius(16f, 16f)
  )
}

private fun DrawScope.drawRoadNetwork(w: Float, h: Float) {
  val majorRoadColor = Color(0xFF1E293B)
  val minorRoadColor = Color(0xFF162032)
  val roadStrokeWidth = 14f

  // Primary Cross Arteries through Wilwal Square
  drawLine(
    color = majorRoadColor,
    start = Offset(0f, h * 0.48f),
    end = Offset(w, h * 0.52f),
    strokeWidth = roadStrokeWidth,
    cap = StrokeCap.Round
  )
  // Crisp White Dashed Line
  drawLine(
    color = Color(0x44FFFFFF),
    start = Offset(0f, h * 0.48f),
    end = Offset(w, h * 0.52f),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
  )

  // North-South Boulevard
  drawLine(
    color = majorRoadColor,
    start = Offset(w * 0.52f, 0f),
    end = Offset(w * 0.46f, h),
    strokeWidth = roadStrokeWidth,
    cap = StrokeCap.Round
  )
  drawLine(
    color = Color(0x44FFFFFF),
    start = Offset(w * 0.52f, 0f),
    end = Offset(w * 0.46f, h),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
  )

  // Diagonals connecting landmarks
  drawLine(
    color = minorRoadColor,
    start = Offset(w * 0.5f, h * 0.5f),
    end = Offset(w * 0.22f, h * 0.82f),
    strokeWidth = 10f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = minorRoadColor,
    start = Offset(w * 0.5f, h * 0.5f),
    end = Offset(w * 0.78f, h * 0.28f),
    strokeWidth = 10f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = minorRoadColor,
    start = Offset(w * 0.68f, h * 0.46f),
    end = Offset(w * 0.86f, h * 0.68f),
    strokeWidth = 10f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = minorRoadColor,
    start = Offset(w * 0.5f, h * 0.5f),
    end = Offset(w * 0.62f, h * 0.64f),
    strokeWidth = 9f,
    cap = StrokeCap.Round
  )
}

private fun DrawScope.drawBajajMarker(
  center: Offset,
  isAssigned: Boolean,
  bearing: Float = 0f,
  plate: String
) {
  val badgeRadius = if (isAssigned) 20f else 14f
  val bodyColor = if (isAssigned) Color(0xFF0284C7) else Color(0xFF2563EB)

  rotate(degrees = bearing, pivot = center) {
    // If assigned, draw front headlight beam cone
    if (isAssigned) {
      val beamPath = Path().apply {
        moveTo(center.x, center.y - 10f)
        lineTo(center.x - 22f, center.y - 48f)
        lineTo(center.x + 22f, center.y - 48f)
        close()
      }
      drawPath(
        path = beamPath,
        brush = Brush.verticalGradient(
          colors = listOf(Color(0x5538BDF8), Color(0x0038BDF8)),
          startY = center.y - 10f,
          endY = center.y - 50f
        )
      )
    }

    // Outer border
    drawCircle(
      color = Color.White,
      radius = badgeRadius + 2f,
      center = center
    )
    drawCircle(
      color = bodyColor,
      radius = badgeRadius,
      center = center
    )

    // Rickshaw 3 wheels
    val frontWheel = Offset(center.x, center.y - 8f)
    val rearLeft = Offset(center.x - 7f, center.y + 7f)
    val rearRight = Offset(center.x + 7f, center.y + 7f)

    drawCircle(color = Color.White, radius = 3f, center = frontWheel)
    drawCircle(color = Color.White, radius = 3f, center = rearLeft)
    drawCircle(color = Color.White, radius = 3f, center = rearRight)

    // White Windshield / Cabin Roof
    drawRoundRect(
      color = Color.White,
      topLeft = Offset(center.x - 5f, center.y - 4f),
      size = Size(10f, 9f),
      cornerRadius = CornerRadius(2.5f, 2.5f)
    )
    drawRoundRect(
      color = Color(0xFF0B192C),
      topLeft = Offset(center.x - 4f, center.y - 3f),
      size = Size(8f, 7f),
      cornerRadius = CornerRadius(1.5f, 1.5f)
    )

    // Headlight pure white glow
    drawCircle(
      color = Color.White,
      radius = 3f,
      center = Offset(center.x, center.y - 10f)
    )
  }
}
