package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bajaj Blue & White shades (Replacing Yellow)
val BajajBluePrimary = Color(0xFF0284C7) // Vibrant Blue
val BajajBlueDark = Color(0xFF0369A1)
val BajajBlueDeep = Color(0xFF1D4ED8) // Royal Blue
val BajajBlueLight = Color(0xFF38BDF8) // Sky Blue
val BajajBlueContainerLight = Color(0xFFE0F2FE) // Soft Ice Blue
val BajajBlueContainerDark = Color(0xFF0C4A6E) // Deep Navy Blue

// Crisp White & Slate Tones
val PureWhite = Color(0xFFFFFFFF)
val SoftWhite = Color(0xFFF8FAFC)
val CardWhite = Color(0xFFFFFFFF)
val BorderWhiteAlpha = Color(0x33FFFFFF)

// Modern Dark & Slate Road Tones
val RoadNavyDark = Color(0xFF0B192C)
val RoadNavyCard = Color(0xFF1E293B)
val RoadNavySurface = Color(0xFF334155)

// Light Background & Surface
val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceTintLight = Color(0xFFE2E8F0)

// Accents
val CyanElectric = Color(0xFF06B6D4)
val EmeraldSuccess = Color(0xFF10B981)
val CoralAlert = Color(0xFFEF4444)

// Text Colors
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
