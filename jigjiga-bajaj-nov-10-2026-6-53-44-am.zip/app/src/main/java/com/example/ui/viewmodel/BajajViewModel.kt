package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.RideHistoryEntity
import com.example.data.local.entity.SavedPlaceEntity
import com.example.data.model.ActiveRide
import com.example.data.model.AppLanguage
import com.example.data.model.BajajDriver
import com.example.data.model.JigjigaLocations
import com.example.data.model.JigjigaPlace
import com.example.data.model.MockDrivers
import com.example.data.model.PaymentType
import com.example.data.model.RideCategory
import com.example.data.model.RideOption
import com.example.data.model.RideStatus
import com.example.data.repository.BajajRideRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.random.Random

enum class UserRole {
  COMMUTER,
  DRIVER
}

data class DriverIncomingRequest(
  val requestId: String,
  val passengerName: String,
  val pickup: JigjigaPlace,
  val dropoff: JigjigaPlace,
  val fareEtb: Int,
  val distanceKm: Float,
  val timeSecondsLeft: Int = 15
)

data class BajajUiState(
  val currentRole: UserRole = UserRole.COMMUTER,
  val language: AppLanguage = AppLanguage.SOMALI,
  val pickup: JigjigaPlace = JigjigaLocations.WilwalSquare,
  val dropoff: JigjigaPlace? = null,
  val passengerLiveX: Float = 50f, // Centered on Wilwal Square by default
  val passengerLiveY: Float = 50f,
  val isMapExpanded: Boolean = false,
  val selectedRideOption: RideOption = RideOption.defaultOptions.first(),
  val selectedPayment: PaymentType = PaymentType.CASH,
  val activeRide: ActiveRide? = null,
  val drivers: List<BajajDriver> = MockDrivers.initialDrivers,
  val isSearchingDriver: Boolean = false,
  val showRatingDialog: Boolean = false,
  val showSosDialog: Boolean = false,
  val showLanguageModal: Boolean = false,
  val showSavePlaceDialog: Boolean = false,
  // Driver Mode specific states
  val isDriverOnline: Boolean = true,
  val driverTodayEarnings: Int = 1420,
  val driverCompletedTrips: Int = 14,
  val incomingDriverRequest: DriverIncomingRequest? = null,
  val isDriverNavigating: Boolean = false
)

class BajajViewModel(application: Application) : AndroidViewModel(application) {
  private val database = AppDatabase.getDatabase(application)
  private val repository = BajajRideRepository(database.rideHistoryDao(), database.savedPlaceDao())
  private val firestoreService = com.example.data.firestore.FirestoreSyncService(application)

  val rideHistory: StateFlow<List<RideHistoryEntity>> = repository.allRides
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val savedPlaces: StateFlow<List<SavedPlaceEntity>> = repository.savedPlaces
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _uiState = MutableStateFlow(BajajUiState())
  val uiState: StateFlow<BajajUiState> = _uiState.asStateFlow()

  private var rideSimulationJob: Job? = null
  private var driverIncomingJob: Job? = null
  private var driverMovementJob: Job? = null

  init {
    viewModelScope.launch {
      repository.populateDefaultsIfNeeded(0)
    }
    startSimulatingNearbyDriverMovements()
    startDriverIncomingRequestsSimulator()
  }

  fun switchRole(role: UserRole) {
    _uiState.update { it.copy(currentRole = role) }
  }

  fun toggleMapExpanded() {
    _uiState.update { it.copy(isMapExpanded = !it.isMapExpanded) }
  }

  fun setLanguage(lang: AppLanguage) {
    _uiState.update { it.copy(language = lang, showLanguageModal = false) }
  }

  fun toggleLanguageModal(show: Boolean) {
    _uiState.update { it.copy(showLanguageModal = show) }
  }

  fun toggleSosDialog(show: Boolean) {
    _uiState.update { it.copy(showSosDialog = show) }
  }

  fun selectPickup(place: JigjigaPlace) {
    _uiState.update {
      it.copy(
        pickup = place,
        passengerLiveX = place.mapX,
        passengerLiveY = place.mapY
      )
    }
  }

  fun updatePassengerLocation(x: Float, y: Float) {
    _uiState.update {
      it.copy(
        passengerLiveX = x.coerceIn(15f, 90f),
        passengerLiveY = y.coerceIn(15f, 90f)
      )
    }
  }

  fun recenterOnPassenger() {
    val pickup = _uiState.value.pickup
    _uiState.update {
      it.copy(
        passengerLiveX = pickup.mapX,
        passengerLiveY = pickup.mapY
      )
    }
  }

  fun selectDropoff(place: JigjigaPlace) {
    _uiState.update { it.copy(dropoff = place) }
  }

  fun selectRideCategory(category: RideCategory) {
    val option = RideOption.defaultOptions.firstOrNull { it.category == category }
      ?: RideOption.defaultOptions.first()
    _uiState.update { it.copy(selectedRideOption = option) }
  }

  fun selectPayment(payment: PaymentType) {
    _uiState.update { it.copy(selectedPayment = payment) }
  }

  fun calculateTripDistance(): Float {
    val state = _uiState.value
    val drop = state.dropoff ?: return 2.5f
    val dx = (drop.mapX - state.passengerLiveX) * 0.08f
    val dy = (drop.mapY - state.passengerLiveY) * 0.08f
    val dist = hypot(dx, dy)
    return (dist * 10f).coerceIn(1.2f, 9.5f)
  }

  fun calculateFare(): Int {
    val dist = calculateTripDistance()
    return _uiState.value.selectedRideOption.calculateFare(dist)
  }

  fun startBookingRide() {
    val state = _uiState.value
    val destination = state.dropoff ?: JigjigaLocations.TaiwanMarket
    val fare = calculateFare()
    val randomOtp = (1000..9999).random().toString()
    val passengerX = state.passengerLiveX
    val passengerY = state.passengerLiveY

    _uiState.update {
      it.copy(
        isSearchingDriver = true,
        dropoff = destination
      )
    }

    rideSimulationJob?.cancel()
    rideSimulationJob = viewModelScope.launch {
      // Step 1: Searching for nearby Bajaj driver (2.5 seconds)
      delay(2400)
      val chosenDriver = state.drivers.random()
      val initialDistanceMeters = ((hypot(chosenDriver.currentX - passengerX, chosenDriver.currentY - passengerY) * 25f).toInt() + 350).coerceIn(400, 1500)
      val initialBearing = Math.toDegrees(atan2((passengerY - chosenDriver.currentY).toDouble(), (passengerX - chosenDriver.currentX).toDouble())).toFloat()

      val ride = ActiveRide(
        rideId = "BJ-${Random.nextInt(10000, 99999)}",
        pickup = state.pickup,
        destination = destination,
        option = state.selectedRideOption,
        driver = chosenDriver,
        fareEtb = fare,
        paymentType = state.selectedPayment,
        status = RideStatus.DRIVER_ASSIGNED,
        otpCode = randomOtp,
        currentProgress = 0f,
        currentBajajX = chosenDriver.currentX,
        currentBajajY = chosenDriver.currentY,
        driverBearing = initialBearing,
        passengerX = passengerX,
        passengerY = passengerY,
        distanceToPassengerMeters = initialDistanceMeters,
        driverSpeedKmh = 28,
        remainingMinutes = (initialDistanceMeters / 400).coerceAtLeast(1)
      )

      _uiState.update {
        it.copy(
          isSearchingDriver = false,
          activeRide = ride
        )
      }

      // Step 2: Real-time driver approach toward passenger (8 progressive steps)
      val approachSteps = 8
      val startX = chosenDriver.currentX
      val startY = chosenDriver.currentY

      for (step in 1..approachSteps) {
        delay(750)
        val progress = step.toFloat() / approachSteps.toFloat()
        val currX = startX + (passengerX - startX) * progress
        val currY = startY + (passengerY - startY) * progress
        val remainingDist = ((1f - progress) * initialDistanceMeters).toInt()
        val speed = Random.nextInt(25, 36)
        val minutesLeft = ((1f - progress) * 3).toInt().coerceAtLeast(0)
        val bearing = Math.toDegrees(atan2((passengerY - currY).toDouble(), (passengerX - currX).toDouble())).toFloat()

        _uiState.update { current ->
          current.activeRide?.let { r ->
            current.copy(
              activeRide = r.copy(
                currentBajajX = currX,
                currentBajajY = currY,
                driverBearing = bearing,
                distanceToPassengerMeters = remainingDist,
                driverSpeedKmh = speed,
                remainingMinutes = minutesLeft
              )
            )
          } ?: current
        }
      }

      // Step 3: Driver arrived at passenger's location!
      _uiState.update { current ->
        current.activeRide?.let { r ->
          current.copy(
            activeRide = r.copy(
              status = RideStatus.DRIVER_ARRIVED,
              currentBajajX = passengerX,
              currentBajajY = passengerY,
              distanceToPassengerMeters = 0,
              driverSpeedKmh = 0,
              remainingMinutes = 0
            )
          )
        } ?: current
      }

      // Wait 3 seconds for boarding
      delay(3000)

      // Step 4: Passenger boarded & In Trip to Destination (10 real-time steps)
      val tripSteps = 10
      val destX = destination.mapX
      val destY = destination.mapY
      val tripBearing = Math.toDegrees(atan2((destY - passengerY).toDouble(), (destX - passengerX).toDouble())).toFloat()

      for (step in 1..tripSteps) {
        val progress = step.toFloat() / tripSteps.toFloat()
        val currX = passengerX + (destX - passengerX) * progress
        val currY = passengerY + (destY - passengerY) * progress
        val speed = Random.nextInt(28, 42)
        val remainingMins = ((1f - progress) * 6).toInt().coerceAtLeast(1)
        val remainingDist = ((1f - progress) * 2800).toInt()

        _uiState.update { current ->
          current.activeRide?.let { r ->
            current.copy(
              passengerLiveX = currX, // Passenger travels with Bajaj!
              passengerLiveY = currY,
              activeRide = r.copy(
                status = RideStatus.ON_TRIP,
                currentProgress = progress,
                currentBajajX = currX,
                currentBajajY = currY,
                passengerX = currX,
                passengerY = currY,
                driverBearing = tripBearing,
                driverSpeedKmh = speed,
                distanceToPassengerMeters = remainingDist,
                remainingMinutes = remainingMins
              )
            )
          } ?: current
        }
        delay(1100)
      }

      // Step 5: Arrived at destination & Completed!
      _uiState.update { current ->
        current.activeRide?.let { r ->
          current.copy(
            passengerLiveX = destX,
            passengerLiveY = destY,
            activeRide = r.copy(
              status = RideStatus.COMPLETED,
              currentProgress = 1f,
              currentBajajX = destX,
              currentBajajY = destY,
              passengerX = destX,
              passengerY = destY,
              driverSpeedKmh = 0,
              remainingMinutes = 0
            ),
            showRatingDialog = true
          )
        } ?: current
      }

      // Record to Room Database & Firestore Cloud
      repository.insertCompletedRide(
        pickup = state.pickup.localizedName(state.language),
        destination = destination.localizedName(state.language),
        fareEtb = fare,
        driverName = chosenDriver.name,
        plateNumber = chosenDriver.plateNumber,
        category = state.selectedRideOption.category.name,
        paymentType = state.selectedPayment.displayName,
        rating = 5
      )
      firestoreService.recordRideToCloud(ride)
    }
  }

  fun cancelRide() {
    rideSimulationJob?.cancel()
    _uiState.update {
      it.copy(
        activeRide = null,
        isSearchingDriver = false,
        showRatingDialog = false
      )
    }
  }

  fun submitRating(rating: Int) {
    _uiState.update {
      it.copy(
        activeRide = null,
        showRatingDialog = false
      )
    }
  }

  // Driver Mode Actions
  fun toggleDriverOnline() {
    _uiState.update { it.copy(isDriverOnline = !it.isDriverOnline) }
  }

  fun acceptIncomingDriverRequest() {
    val req = _uiState.value.incomingDriverRequest ?: return
    driverIncomingJob?.cancel()
    _uiState.update {
      it.copy(
        incomingDriverRequest = null,
        isDriverNavigating = true,
        driverTodayEarnings = it.driverTodayEarnings + req.fareEtb,
        driverCompletedTrips = it.driverCompletedTrips + 1
      )
    }
  }

  fun declineIncomingDriverRequest() {
    _uiState.update { it.copy(incomingDriverRequest = null) }
  }

  fun completeDriverTrip() {
    _uiState.update { it.copy(isDriverNavigating = false) }
  }

  fun saveCustomPlace(label: String, place: JigjigaPlace) {
    viewModelScope.launch {
      val entity = SavedPlaceEntity(
        placeId = "custom_${System.currentTimeMillis()}",
        customLabel = label,
        locationName = place.nameEn,
        mapX = place.mapX,
        mapY = place.mapY,
        iconTag = "STAR"
      )
      repository.saveCustomPlace(entity)
    }
  }

  fun deleteSavedPlace(placeId: String) {
    viewModelScope.launch {
      repository.deleteSavedPlace(placeId)
    }
  }

  private fun startSimulatingNearbyDriverMovements() {
    driverMovementJob?.cancel()
    driverMovementJob = viewModelScope.launch {
      while (true) {
        delay(3000)
        _uiState.update { state ->
          val activeDriverId = state.activeRide?.driver?.id
          val updatedDrivers = state.drivers.map { driver ->
            if (driver.id == activeDriverId) {
              // Active driver is driven by ride loop
              driver
            } else {
              val deltaX = (Random.nextFloat() - 0.5f) * 1.5f
              val deltaY = (Random.nextFloat() - 0.5f) * 1.5f
              driver.copy(
                currentX = (driver.currentX + deltaX).coerceIn(20f, 85f),
                currentY = (driver.currentY + deltaY).coerceIn(20f, 85f)
              )
            }
          }
          state.copy(drivers = updatedDrivers)
        }
      }
    }
  }

  private fun startDriverIncomingRequestsSimulator() {
    driverIncomingJob?.cancel()
    driverIncomingJob = viewModelScope.launch {
      while (true) {
        delay(16000)
        if (_uiState.value.currentRole == UserRole.DRIVER && _uiState.value.isDriverOnline && !_uiState.value.isDriverNavigating) {
          val p1 = JigjigaLocations.allPlaces.random()
          var p2 = JigjigaLocations.allPlaces.random()
          while (p2.id == p1.id) {
            p2 = JigjigaLocations.allPlaces.random()
          }
          val fare = (40..160).random()
          val dist = Random.nextFloat() * 4.5f + 1.2f
          val names = listOf("Khadra Yasin", "Sahra Abdi", "Mahamed Ali", "Fatuma Omar", "Ibrahim Deeq")

          _uiState.update {
            it.copy(
              incomingDriverRequest = DriverIncomingRequest(
                requestId = "REQ-${(100..999).random()}",
                passengerName = names.random(),
                pickup = p1,
                dropoff = p2,
                fareEtb = fare,
                distanceKm = (dist * 10).toInt() / 10f
              )
            )
          }
        }
      }
    }
  }

  override fun onCleared() {
    super.onCleared()
    rideSimulationJob?.cancel()
    driverIncomingJob?.cancel()
    driverMovementJob?.cancel()
  }
}
