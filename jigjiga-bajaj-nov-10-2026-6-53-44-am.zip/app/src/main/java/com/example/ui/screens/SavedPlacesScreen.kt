package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SavedPlaceEntity
import com.example.data.model.JigjigaLocations
import com.example.data.model.JigjigaPlace
import com.example.data.model.LocalizedStrings
import com.example.ui.viewmodel.BajajViewModel

@Composable
fun SavedPlacesScreen(
  viewModel: BajajViewModel,
  onNavigateToRide: (JigjigaPlace) -> Unit,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val savedList by viewModel.savedPlaces.collectAsState()
  val strings = LocalizedStrings.get(uiState.language)
  var showAddDialog by remember { mutableStateOf(false) }

  Box(modifier = modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Text(
        text = "⭐ ${strings.savedPlaces}",
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
      )
      Spacer(modifier = Modifier.height(12.dp))

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
      ) {
        items(savedList, key = { it.placeId }) { place ->
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("saved_place_item_${place.placeId}")
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(44.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = when (place.iconTag) {
                      "HOME" -> Icons.Default.Home
                      "WORK" -> Icons.Default.ShoppingCart
                      "SCHOOL" -> Icons.Default.School
                      else -> Icons.Default.Star
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                }
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = place.customLabel,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = place.locationName,
                  style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
              }

              // Ride shortcut button
              Button(
                onClick = {
                  val matchedPlace = JigjigaLocations.allPlaces.find { it.nameEn == place.locationName || it.nameSo == place.locationName }
                    ?: JigjigaLocations.allPlaces.first()
                  onNavigateToRide(matchedPlace)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.testTag("ride_to_place_${place.placeId}")
              ) {
                Text("Ride Here", fontSize = 12.sp)
              }

              IconButton(
                onClick = { viewModel.deleteSavedPlace(place.placeId) },
                modifier = Modifier.testTag("delete_saved_place_${place.placeId}")
              ) {
                Icon(
                  Icons.Default.Delete,
                  contentDescription = "Delete",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
              }
            }
          }
        }
      }
    }

    // Add Place Floating Action Button
    FloatingActionButton(
      onClick = { showAddDialog = true },
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = MaterialTheme.colorScheme.onPrimary,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp)
        .testTag("add_saved_place_fab")
    ) {
      Icon(Icons.Default.Add, contentDescription = "Add Place")
    }

    if (showAddDialog) {
      AddPlaceDialog(
        onDismiss = { showAddDialog = false },
        onSave = { label, place ->
          viewModel.saveCustomPlace(label, place)
          showAddDialog = false
        }
      )
    }
  }
}

@Composable
fun AddPlaceDialog(
  onDismiss: () -> Unit,
  onSave: (String, JigjigaPlace) -> Unit
) {
  var label by remember { mutableStateOf("") }
  var selectedPlace by remember { mutableStateOf(JigjigaLocations.allPlaces.first()) }
  var dropdownExpanded by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Save Favorite Jigjiga Location", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = label,
          onValueChange = { label = it },
          label = { Text("Label (e.g. My Shop / Hotel)") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("new_place_label_input")
        )

        Column {
          Text(
            text = "Select Landmark Area:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .fillMaxWidth()
              .clickable { dropdownExpanded = true }
              .padding(12.dp)
          ) {
            Text(text = selectedPlace.nameEn, fontWeight = FontWeight.Medium)
          }

          DropdownMenu(
            expanded = dropdownExpanded,
            onDismissRequest = { dropdownExpanded = false }
          ) {
            JigjigaLocations.allPlaces.forEach { place ->
              DropdownMenuItem(
                text = { Text(place.nameEn) },
                onClick = {
                  selectedPlace = place
                  dropdownExpanded = false
                }
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (label.isNotBlank()) {
            onSave(label, selectedPlace)
          }
        },
        modifier = Modifier.testTag("save_place_confirm_button")
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
