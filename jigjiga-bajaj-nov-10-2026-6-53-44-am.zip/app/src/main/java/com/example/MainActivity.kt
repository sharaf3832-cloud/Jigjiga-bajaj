package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.auth.AuthManager
import com.example.data.model.LocalizedStrings
import com.example.ui.components.UserAccountDialog
import com.example.ui.screens.CommuterHomeScreen
import com.example.ui.screens.DriverModeScreen
import com.example.ui.screens.RideHistoryScreen
import com.example.ui.screens.SavedPlacesScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BajajViewModel
import com.example.ui.viewmodel.UserRole

enum class AppNavDestination(val testTag: String) {
  COMMUTER("nav_commuter"),
  DRIVER("nav_driver"),
  HISTORY("nav_history"),
  SAVED_PLACES("nav_saved_places")
}

class MainActivity : ComponentActivity() {
  private val viewModel: BajajViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        MainAppContent(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun MainAppContent(viewModel: BajajViewModel) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val authManager = remember { AuthManager(context.applicationContext) }
  val currentUser by authManager.currentUser.collectAsState()

  val uiState by viewModel.uiState.collectAsState()
  val strings = LocalizedStrings.get(uiState.language)
  var currentTab by remember { mutableStateOf(AppNavDestination.COMMUTER) }
  var showAccountDialog by remember { mutableStateOf(false) }

  // Attempt silent auto sign-in on launch
  LaunchedEffect(Unit) {
    authManager.attemptAutoSignIn(scope)
  }

  // Handle system back button
  BackHandler(enabled = currentTab != AppNavDestination.COMMUTER) {
    currentTab = AppNavDestination.COMMUTER
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      NavigationBar(
        modifier = Modifier
          .navigationBarsPadding()
          .testTag("main_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
      ) {
        // Tab 1: Commuter
        NavigationBarItem(
          selected = currentTab == AppNavDestination.COMMUTER,
          onClick = {
            currentTab = AppNavDestination.COMMUTER
            viewModel.switchRole(UserRole.COMMUTER)
          },
          icon = {
            Icon(
              if (currentTab == AppNavDestination.COMMUTER) Icons.Filled.Person else Icons.Outlined.Person,
              contentDescription = strings.commuterMode
            )
          },
          label = {
            Text(
              text = strings.commuterMode,
              fontWeight = if (currentTab == AppNavDestination.COMMUTER) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
            selectedTextColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag(AppNavDestination.COMMUTER.testTag)
        )

        // Tab 2: Driver Mode
        NavigationBarItem(
          selected = currentTab == AppNavDestination.DRIVER,
          onClick = {
            currentTab = AppNavDestination.DRIVER
            viewModel.switchRole(UserRole.DRIVER)
          },
          icon = {
            Icon(
              if (currentTab == AppNavDestination.DRIVER) Icons.Filled.DirectionsCar else Icons.Outlined.DirectionsCar,
              contentDescription = strings.driverMode
            )
          },
          label = {
            Text(
              text = strings.driverMode,
              fontWeight = if (currentTab == AppNavDestination.DRIVER) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
            selectedTextColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag(AppNavDestination.DRIVER.testTag)
        )

        // Tab 3: History
        NavigationBarItem(
          selected = currentTab == AppNavDestination.HISTORY,
          onClick = { currentTab = AppNavDestination.HISTORY },
          icon = {
            Icon(
              if (currentTab == AppNavDestination.HISTORY) Icons.Filled.History else Icons.Outlined.History,
              contentDescription = strings.history
            )
          },
          label = {
            Text(
              text = strings.history,
              fontWeight = if (currentTab == AppNavDestination.HISTORY) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
            selectedTextColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag(AppNavDestination.HISTORY.testTag)
        )

        // Tab 4: Saved Places
        NavigationBarItem(
          selected = currentTab == AppNavDestination.SAVED_PLACES,
          onClick = { currentTab = AppNavDestination.SAVED_PLACES },
          icon = {
            Icon(
              if (currentTab == AppNavDestination.SAVED_PLACES) Icons.Filled.Star else Icons.Outlined.Star,
              contentDescription = strings.savedPlaces
            )
          },
          label = {
            Text(
              text = strings.savedPlaces,
              fontWeight = if (currentTab == AppNavDestination.SAVED_PLACES) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
            selectedTextColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag(AppNavDestination.SAVED_PLACES.testTag)
        )
      }
    }
  ) { innerPadding ->
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      color = MaterialTheme.colorScheme.background
    ) {
      AnimatedContent(targetState = currentTab, label = "tab_transition") { tab ->
        when (tab) {
          AppNavDestination.COMMUTER -> {
            CommuterHomeScreen(
              viewModel = viewModel,
              uiState = uiState,
              onOpenAccount = { showAccountDialog = true }
            )
          }

          AppNavDestination.DRIVER -> {
            DriverModeScreen(
              viewModel = viewModel,
              uiState = uiState
            )
          }

          AppNavDestination.HISTORY -> {
            RideHistoryScreen(
              viewModel = viewModel,
              onRebook = { currentTab = AppNavDestination.COMMUTER }
            )
          }

          AppNavDestination.SAVED_PLACES -> {
            SavedPlacesScreen(
              viewModel = viewModel,
              onNavigateToRide = { place ->
                viewModel.selectDropoff(place)
                viewModel.switchRole(UserRole.COMMUTER)
                currentTab = AppNavDestination.COMMUTER
              }
            )
          }
        }
      }
    }

    if (showAccountDialog) {
      UserAccountDialog(
        user = currentUser,
        authManager = authManager,
        onDismiss = { showAccountDialog = false }
      )
    }
  }
}
